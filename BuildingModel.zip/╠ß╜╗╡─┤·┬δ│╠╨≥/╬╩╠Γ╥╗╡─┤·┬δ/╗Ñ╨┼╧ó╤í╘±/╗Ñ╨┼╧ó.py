from sklearn.feature_selection import SelectKBest,f_classif
from sklearn.feature_selection import chi2
import pandas as pd
import numpy as np
train=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\x_train.csv')   #训练集
validation=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\validation.csv')  #验证集
xtest=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\test.csv')      #测试集

x_train= train.drop(['IC50_nM','pIC50'], axis=1)
y_train=train['pIC50'].values

x_validation= validation.drop(['IC50_nM','pIC50'], axis=1)
y_validation=validation['pIC50'].values

feat_names=x_train.columns

model1 = SelectKBest(score_func= f_classif, k=50)#选择k个最佳特征
model1.fit(x_train, y_train)


all_name = x_train.columns.values.tolist()  # 获得所有的特征名称
select_name_index0 = model1.get_support(indices=True)  # 留下特征的索引值，list格式
select_name0 = []
for i in select_name_index0:
    select_name0.append(all_name[i])

xtrain_chi2=pd.DataFrame(x_train, columns=select_name0)
validation_chi2=pd.DataFrame(x_validation, columns=select_name0)
xtest_chi2=pd.DataFrame(xtest, columns=select_name0)

# print(data_ch)
xtrain_chi2.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题一的代码\互信息选择\互信息选择的前20个特征\xtrain_f_classif.csv',index=False)
validation_chi2.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题一的代码\互信息选择\互信息选择的前20个特征\validation_f_classif.csv',index=False)
xtest_chi2.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题一的代码\互信息选择\互信息选择的前20个特征\xtestf_classif.csv',index=False)