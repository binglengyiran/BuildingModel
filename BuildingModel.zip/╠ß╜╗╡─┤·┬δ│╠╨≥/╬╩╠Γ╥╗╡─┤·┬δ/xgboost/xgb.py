import pandas as pd
import numpy as np
# from xgboost import XGBRegressor
from xgboost import XGBRegressor
from sklearn import metrics
import matplotlib.pyplot as plt
train=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\x_train.csv')   #训练集
validation=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\validation.csv')  #验证集
xtest=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\test.csv')      #测试集

x_train= train.drop(['IC50_nM','pIC50'], axis=1)
y_train=train['pIC50'].values

x_validation= validation.drop(['IC50_nM','pIC50'], axis=1)
y_validation=validation['pIC50'].values

feat_names=x_train.columns

xgb_regress=XGBRegressor(random_state=0)
xgb_regress.fit(x_train,y_train)
y_val=xgb_regress.predict(x_validation)
y_test=xgb_regress.predict(xtest)

feature_importance=xgb_regress.feature_importances_
feature_importance = 100.0 * (feature_importance / feature_importance.max())

fi_threshold =-100
important_idx = np.where(feature_importance > fi_threshold)[0]   #当数据是一维的时候返回的是索引值
important_features_1 = feat_names[important_idx]    #找到满足要求的特征名称

#important_features
sorted_idx = np.argsort(feature_importance[important_idx])[::-1]
#get the figure about important features
pos = np.arange(sorted_idx.shape[0]) +.5
fig = plt.figure(figsize=(12,12))     #如果标签有重叠现象，可通过这个语句来实现标签的不重叠,文字特征有重叠，样本显示不全可通过设置这里进行修改
plt.plot()
plt.title('Feature Importance',fontdict={'size': 30})
plt.barh(pos, feature_importance[important_idx][sorted_idx[::-1]],color='b',align='center')
plt.yticks(pos, important_features_1[sorted_idx[::-1]])
plt.xlabel('Relative Importance',fontdict={'size': 30})
plt.show()


important_data = feature_importance[important_idx]
feature_dx = np.argsort(important_data)[::-1]    #以降序的方式来对数据进行排序
feature_jiangxu = important_data[feature_dx]    #排序之后的数据
feature_jiangxu_name = important_features_1[feature_dx]   #降序之后数据对应的的名称
alldata = pd.Series(feature_jiangxu, index=feature_jiangxu_name)
alldata.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题一实验过程整合\xgboost未调参的重要性排序.csv',header=False)

subdata_bing = pd.concat([pd.DataFrame(y_val), pd.DataFrame(y_validation),pd.DataFrame(y_test)], axis=1)
subdata_bing.columns=['y_validation_predict','y_validation_true','y_test_predict']
subdata_bing.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题一实验过程整合\xgb未调参的验证集的真实值与预测值的拟合以及测试集上的预测.csv',index=False)

print('Mean Absolute Error:', metrics.mean_absolute_error(y_validation, y_val))
print('Mean Squared Error:', metrics.mean_squared_error(y_validation, y_val))

