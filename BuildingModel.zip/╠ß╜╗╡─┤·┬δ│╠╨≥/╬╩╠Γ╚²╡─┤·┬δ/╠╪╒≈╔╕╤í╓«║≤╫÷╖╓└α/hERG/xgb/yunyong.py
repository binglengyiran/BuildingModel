import numpy as np
import pandas as pd
from sklearn.feature_selection import RFE
from sklearn.model_selection import cross_val_score
import linearcorex as lc
from xgboost import XGBClassifier
from xgboost import plot_importance
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score
from sko.GA import GA
from sko.operators import ranking,selection,crossover,mutation

import warnings
warnings.filterwarnings('ignore')

df = pd.read_csv(r'F:\研究生\代码my\不均衡-集成-基因数据集\mashi_diststance\genen.csv', header=None,index_col=0)
# data= pd.read_csv(r'F:\研究生\作业\数据挖掘\CTGRawData.csv')
# data= pd.read_csv(r'F:\shujubao\breast_cancer.csv')
data = df.T
data = data.dropna(axis=0, how='any')
feature=data.drop(['label'],axis=1)
label=data['label'].values

xtrain, xtest, ytrain, ytest = train_test_split(feature,label, test_size=0.1, random_state=0, stratify=label)

ref=RFE(LogisticRegression(),n_features_to_select=200,step=1000,verbose=1)
xtrain_ref=ref.fit_transform(xtrain,ytrain)
xtest_ref=ref.transform(xtest)

x_train, validation, y_train, y_validation = train_test_split(xtrain_ref,ytrain, test_size=0.2, random_state=0, stratify=ytrain)
eval_set=[(validation,y_validation)]
# def XGBC(learning_rate,n_estimators,max_depth):
def XGBC(learning_rate,n_estimators,max_depth,gamma,alpha,reg_lambda):

    lr = XGBClassifier(learning_rate=learning_rate, n_estimators=int(n_estimators), max_depth=int(max_depth),gamma=gamma,reg_alpha=alpha,reg_lambda=reg_lambda,min_child_weight=3,colsample_bytree=0.8,objective='multi:softmax',num_class=4,random_state=0)
    lr.fit(x_train,y_train,eval_metric='merror',early_stopping_rounds=20,eval_set=eval_set)   #merror or mlogloss,   early_stopping_rounds=10,eval_metric='merror',eval_set=eval_set,
    y_pred=lr.predict(xtest_ref)
    # print(confusion_matrix(ytest,y_pred))
    # print(classification_report(ytest,y_pred))
    accuracy = accuracy_score(ytest, y_pred)
    return accuracy

def XGBC_1(learning_rate,n_estimators,max_depth,gamma,alpha,reg_lambda):

    lr = XGBClassifier(learning_rate=learning_rate, n_estimators=int(n_estimators), max_depth=int(max_depth),gamma=gamma,reg_alpha=alpha,reg_lambda=reg_lambda,min_child_weight=3,colsample_bytree=0.8,objective='multi:softmax',num_class=4,scale_pos_weight=1,random_state=0)   #
    # lr = XGBClassifier()
    lr.fit(x_train,y_train,eval_metric='merror',early_stopping_rounds=20,eval_set=eval_set)   #merror or mlogloss,   early_stopping_rounds=10,eval_metric='merror',eval_set=eval_set,
    y_pred=lr.predict(xtest_ref)
    print(confusion_matrix(ytest,y_pred))
    print(classification_report(ytest,y_pred))
    accuracy = accuracy_score(ytest, y_pred)
    return accuracy

def my_canshu(p):  #定义寻优参数
    learning_rate,n_estimators,max_depth,gamma,alpha,reg_lambda=p   #这里的p是一个集合，里面存放的是求解的参数
    return -XGBC(learning_rate,n_estimators,max_depth,gamma,alpha,reg_lambda)   #找到测试集当中准确率最大的值

print('遗传算法开始寻优')   #func函数指的是我要优化的问题
# ga=GA(func=my_canshu,n_dim=6,size_pop=200,max_iter=300,lb=[0.01,100,3,0.005,0.01,0.1],ub=[0.32,1100,10,0.1,0.1,0.3],precision=[1e-5,1,1,1e-5,1e-5,1e-5],prob_mut=0.02)   #precision表示每一个变量的精度,当对应的变量为整数时，即对该参数进行参数优化
# ga.register(operator_name='ranking',operator=ranking.ranking)
# ga.register(operator_name='selection',operator=selection.selection_roulette_1)        #选择遗传算子
# ga.register(operator_name='crossover',operator=crossover.crossover_2point_prob,crossover_prob=0.7)
# ga.register(operator_name='mutation',operator=mutation.mutation)
#
# best_theta,best_residuals = ga.run()    #做遗传算子运算
# print("遗传算法运行结束")
# Y_history = pd.DataFrame(ga.all_history_Y)
# fig, ax = plt.subplots(2, 1)
# ax[0].plot(Y_history.index, Y_history.values, '.', color='red')
# Y_history.min(axis=1).cummin().plot(kind='line')
# plt.show()



# print('best_alpa:',best_theta)
# learning_rate=best_theta[0]
# n_estimators=best_theta[1]
# max_depth=best_theta[2]
# gamma=best_theta[3]
# alpha=best_theta[4]
# reg_lambda=best_theta[5]
learning_rate=3.17890255e-01
n_estimators=1.09800000e+03
max_depth=5.00000000e+00
gamma=3.92644815e-02
alpha=1.49826039e-02
reg_lambda=1.02630696e-01

XGBC_1(learning_rate,n_estimators,max_depth,gamma,alpha,reg_lambda)