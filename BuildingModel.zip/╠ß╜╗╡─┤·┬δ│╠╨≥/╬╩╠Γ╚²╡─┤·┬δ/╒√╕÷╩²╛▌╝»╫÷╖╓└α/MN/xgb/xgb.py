import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from xgboost import XGBClassifier
# from sklearn.naive_bayes import
from sklearn.preprocessing import label_binarize
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,recall_score,f1_score,confusion_matrix, accuracy_score,precision_score,roc_curve
import warnings
warnings.filterwarnings('ignore')

#导入数据集

train=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题三_分类数据集\train\Molecular_MN.csv')
xtest=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题三_分类数据集\test\test_Molecular_MN.csv')
xtrain= train.drop(['MN'], axis=1)
ytrain = train['MN'].values



#统计类别分布
label_count=train.groupby('MN',as_index=False).count()
class_name=list(label_count['MN'])
count=list(label_count['nAcid'])
print('类别数有:')
print(count)   #类别的数量
index=np.arange(len(class_name))
sns.barplot(x=class_name,y=count,linewidth=2.5,errcolor='.2',edgecolor='.2')
# plt.xlabel('Class',fontdict=15)
# plt.ylabel('Number of data',fontdict=15)
# plt.xticks(index,class_name,fontsize=15)
plt.title('Class distribution')
plt.show()

# 计算相关性，可用于第二问
# cor=train.corr()
# plt.figure(figsize=(16,10))
# sns.heatmap(cor)
# plt.show()


#分类器
random_state=0
class Create_ensemble(object):
    def __init__(self, n_splits, base_models):
        self.n_splits = n_splits
        self.base_models = base_models

    def predict(self, X, y,T):
        X = np.array(X)
        y = np.array(y)
        T=np.array(T)
        no_class = len(np.unique(y))

        folds = list(StratifiedKFold(n_splits=self.n_splits, shuffle=True,
                                     random_state=random_state).split(X, y))

        train_proba = np.zeros((X.shape[0], no_class))
        test_proba = np.zeros((T.shape[0], no_class))

        train_pred = np.zeros((X.shape[0], len(self.base_models)))
        test_pred = np.zeros((T.shape[0], len(self.base_models)*self.n_splits))

        f1_scores = np.zeros((len(self.base_models), self.n_splits))
        recall_scores = np.zeros((len(self.base_models), self.n_splits))
        test_col=0

        for i, clf in enumerate(self.base_models):

            for j, (train_idx, valid_idx) in enumerate(folds):
                X_train = X[train_idx]
                Y_train = y[train_idx]
                X_valid = X[valid_idx]
                Y_valid = y[valid_idx]

                clf.fit(X_train, Y_train)

                valid_pred = clf.predict(X_valid)
                recall = recall_score(Y_valid, valid_pred, average='weighted')
                f1 = f1_score(Y_valid, valid_pred, average='weighted')

                recall_scores[i][j] = recall
                f1_scores[i][j] = f1

                train_pred[valid_idx, i] = valid_pred
                test_pred[:,test_col]=clf.predict(T)
                test_col+=1


                ## Probabilities
                valid_proba = clf.predict_proba(X_valid)  # 计算验证的概率
                train_proba[valid_idx, :] = valid_proba  # 计算测试集的概率
                test_proba+=clf.predict_proba(T)

                print("Model- {} and CV- {} recall: {}, f1_score: {}".format(i, j, recall, f1))
            test_proba/=self.n_splits


        return train_proba, test_proba,train_pred,test_pred


lr = XGBClassifier()
base_models = [lr]
n_splits = 10
lgb_stack = Create_ensemble(n_splits = n_splits, base_models = base_models)
train_proba, test_proba,train_pred,test_pred = lgb_stack.predict(xtrain,ytrain,xtest)
print(confusion_matrix(ytrain,train_pred))
print(classification_report(ytrain,train_pred))

