import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics
import matplotlib.pyplot as plt
from sko.GA import GA
from sko.operators import ranking,selection,crossover,mutation


train=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\x_train.csv')   #训练集
validation=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\validation.csv')  #验证集
xtest=pd.read_csv(r'F:\2021数学建模试题\建模竞赛D题\数据集整合\问题一_回归数据整合\test.csv')      #测试集
# select_name=['MDEC-23','LipoaffinityIndex','C1SP2','maxHsOH','minsssN','minHsOH','maxssO','minsOH','nHBAcc','minHBint5','MLFER_A','BCUTc-1l','VC-5','MDEO-12','ndssC','MLogP','minHssNH','BCUTp-1h','SHBint10','nC']
select_name=['MDEC-23','LipoaffinityIndex','C1SP2','maxHsOH','minsssN','minHsOH','maxssO','minsOH','nHBAcc','minHBint5','MLFER_A','BCUTc-1l','VC-5','MDEO-12','ndssC','MLogP']

x_train= pd.DataFrame(train,columns=select_name)
y_train=train['pIC50'].values

x_validation= pd.DataFrame(validation,columns=select_name)
y_validation=validation['pIC50'].values

x_test= pd.DataFrame(xtest,columns=select_name)
feat_names=x_train.columns

def xunyou_1(n_estimators,max_depth,min_samples_split,min_samples_leaf):
    regress=RandomForestRegressor(n_estimators=n_estimators,max_depth=max_depth,min_samples_split=min_samples_split,min_samples_leaf=min_samples_leaf,random_state=0)

    regress.fit(x_train,y_train)
    y_val=regress.predict(x_validation)
    y_test=regress.predict(x_test)     #在测试集上的预测


    plt.plot(y_validation,linewidth=1)
    plt.plot(y_val,linewidth=1)
    feature_importance=regress.feature_importances_
    feature_importance = 100.0 * (feature_importance / feature_importance.max())

    fi_threshold =-100
    important_idx = np.where(feature_importance > fi_threshold)[0]   #当数据是一维的时候返回的是索引值
    important_features_1 = feat_names[important_idx]    #找到满足要求的特征名称

#important_features
    sorted_idx = np.argsort(feature_importance[important_idx])[::-1]
    #get the figure about important features
    pos = np.arange(sorted_idx.shape[0]) +.5
    fig = plt.figure(figsize=(12,12))     #如果标签有重叠现象，可通过这个语句来实现标签的不重叠,文字特征有重叠，样本显示不全可通过设置这里进行修改
    plt.plot()
    plt.title('Feature Importance',fontdict={'size': 30})
    plt.barh(pos, feature_importance[important_idx][sorted_idx[::-1]],color='b',align='center')
    plt.yticks(pos, important_features_1[sorted_idx[::-1]])
    plt.xlabel('Relative Importance',fontdict={'size': 30})
    plt.show()


    important_data = feature_importance[important_idx]
    feature_dx = np.argsort(important_data)[::-1]    #以降序的方式来对数据进行排序
    feature_jiangxu = important_data[feature_dx]    #排序之后的数据
    feature_jiangxu_name = important_features_1[feature_dx]   #降序之后数据对应的的名称
    alldata = pd.Series(feature_jiangxu, index=feature_jiangxu_name)
    alldata.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题二的代码\遗传算法优化随机森林模型\随机森林遗传算法寻优的重要性排序.csv',header=False)

    subdata_bing = pd.concat([pd.DataFrame(y_val), pd.DataFrame(y_validation),pd.DataFrame(y_test)], axis=1)
    subdata_bing.columns=['y_validation_predict','y_validation_true','y_test_predict']
    subdata_bing.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题二的代码\遗传算法优化随机森林模型\随机森林遗传算法寻优的验证集的真实值与预测值的拟合以及测试集上的预测.csv',index=False)

    print('Mean Absolute Error:', metrics.mean_absolute_error(y_validation, y_val))
    print('Mean Squared Error:', metrics.mean_squared_error(y_validation, y_val))


def xunyou(n_estimators, max_depth, min_samples_split, min_samples_leaf):
    regress = RandomForestRegressor(n_estimators=int(n_estimators), max_depth=int(max_depth), min_samples_split=int(min_samples_split),
                                    min_samples_leaf=int(min_samples_leaf),
                                    random_state=0)
    regress.fit(x_train, y_train)
    y_val = regress.predict(x_validation)
    # y_test = regress.predict(xtest)  # 在测试集上的预测
    mean_absolute=metrics.mean_absolute_error(y_validation, y_val)
    print('lalallala')
    return mean_absolute

def my_canshu(p):  #定义寻优参数
    n_estimators, max_depth, min_samples_split, min_samples_leaf=p   #这里的p是一个集合，里面存放的是求解的参数
    return xunyou(n_estimators, max_depth, min_samples_split, min_samples_leaf)   #找到测试集当中准确率最大的值

# print('遗传算法开始寻优')   #func函数指的是我要优化的问题
# ga=GA(func=my_canshu,n_dim=4,size_pop=100,max_iter=100,lb=[10,1,2,2],ub=[201,21,21,21],precision=[5,1,1,1],prob_mut=0.02)   #precision表示每一个变量的精度,当对应的变量为整数时，即对该参数进行参数优化
# ga.register(operator_name='ranking',operator=ranking.ranking)
# ga.register(operator_name='selection',operator=selection.selection_roulette_1)        #选择遗传算子
# ga.register(operator_name='crossover',operator=crossover.crossover_2point_prob,crossover_prob=0.7)
# ga.register(operator_name='mutation',operator=mutation.mutation)
#
# best_theta,best_residuals = ga.run()    #做遗传算子运算
# print('最优的参数',best_theta)
# print("遗传算法运行结束")
# n_estimators=best_theta[0]
# max_depth=best_theta[1]
# min_samples_split=best_theta[2]
# min_samples_leaf=best_theta[3]
#
# best_generation_best_Y=pd.DataFrame(ga.generation_best_Y)
# best_generation_best_X=pd.DataFrame(ga.generation_best_X)
# opt_X_Y=pd.concat([best_generation_best_X, best_generation_best_Y], axis=1)
# opt_X_Y.columns=['n_estimators','max_depth','min_samples_split','min_samples_leaf','best_generation_best_Y']
# opt_X_Y.to_csv(r'F:\2021数学建模试题\建模竞赛D题\python代码\问题二的代码\遗传算法优化随机森林模型\遗传算法对参数寻优后每代最优的X和Y值.csv')
# Y_history = pd.DataFrame(ga.all_history_Y)
# fig, ax = plt.subplots(2, 1)
# ax[0].plot(Y_history.index, Y_history.values, '.', color='red')
# Y_history.min(axis=1).cummin().plot(kind='line')
# plt.show()

xunyou_1(15,20,2,2)